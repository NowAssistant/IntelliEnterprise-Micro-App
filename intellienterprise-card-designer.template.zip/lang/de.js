
! function() {
  Polymer.atI18nLocales.add('at-empdir', 'de', {
    manager: 'Vorgesetzter'    
  });
}();
