
! function() {
  Polymer.atI18nLocales.add($namePrefix, 'en', {
    manager: 'Manager'
  });
}();
